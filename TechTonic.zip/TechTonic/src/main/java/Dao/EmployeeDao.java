package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import conections.GetConnection;
import pojo.Employees_pojo;
import pojo.Login;
import pojo.MyTechPojo;
import pojo.TechPojo;

public class EmployeeDao {
	
	Connection con = null;
	
	public boolean isExist(String email) throws SQLException
	{
		
		con =  GetConnection.getConnection();
		Statement stmt=con.createStatement();
		String query = "SELECT * from employees where email='"+email+"'" ;
		boolean result;
		if(stmt.executeQuery(query).next())		
			result=true;
		else result = false;
		con.close();
		return result;
		
		
	}
	
	public boolean registerEmployee(Employees_pojo e1) throws SQLException
	{
		con =  GetConnection.getConnection();
		Statement stmt=con.createStatement();
		String email = e1.getEmail();
		String name = e1.getName();
		String password = e1.getPassword();
		
		if(!isExist(email))
		{
					
		String query = "INSERT INTO employees values('"+email+"','"+name+"','"+password+"')" ;
		
		boolean result =  stmt.execute(query);
		System.out.println(result);
		con.close();
		return true;
		}
		else
			return false;
		
	}
	
	public boolean loginVarification(Login e1) throws SQLException
	{
		con =  GetConnection.getConnection();
		Statement stmt=con.createStatement();
		
		String email = e1.getEmail();		
		String password = e1.getPassword();
		
		String query = "SELECT * from employees where email='"+email+"' and password='"+password+"'" ;
		boolean result;
		
		
		if(stmt.executeQuery(query).next())		
			result=true;
		else result = false;
		con.close();
		return result;
	}
	
	public ArrayList<TechPojo> getTechDetails() throws SQLException
	{
		System.out.println("i am hoooooooooooooooooooooooooo1111111111111");
		ArrayList<TechPojo> l1 = new ArrayList<TechPojo>();
		con =  GetConnection.getConnection();
		/*Statement stmt=con.createStatement();
		String query = "SELECT dateOfLacture,tital,discription,prasentator FROM TechDetail" ;
		ResultSet rst = stmt.executeQuery(query);*/
		
		
		PreparedStatement stmt = con.prepareStatement("SELECT * FROM TechDetail");
		ResultSet rst= stmt.executeQuery();
		
		
		//System.out.println("i am hoooooooooooooooooooooooooo22222222222222222222");
		
		while(rst.next())
		{
			
			String dateOfLecture = rst.getDate("dateOfLacture")+"";
			String tital = rst.getString("tital");
			String discription = rst.getString("discription");
			String prentator = rst.getString("prasentator");
			String interested = rst.getString("interested");
			System.out.println(dateOfLecture);
			l1.add(new TechPojo(dateOfLecture, tital, discription, prentator,interested));
			
		}
		
		con.close();
		return l1;
		
	}
	
	public int addtomytechdetail(MyTechPojo p_new) throws SQLException
	{
		
		
		
		
		String dateOfLecture = p_new.getDateOfLecture();
		String tital = p_new.getTital();
		String discription = p_new.getDiscription();
	
		String prentator = p_new.getPrentator();
		//String interested = p_new.getInterested();
		String email = p_new.getEmail();
		con =  GetConnection.getConnection();
		Statement stm = con.createStatement();
		String query = "insert into MyTechDetail values( '"+email+"',TO_DATE ( '"+dateOfLecture+"','YYYY/MM/DD' ),'"+tital+"','"+discription+"','"+prentator+"')";
		System.out.println(query+"uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuooooooooooooooooooo");
		int result = stm.executeUpdate(query);
		con.commit();
		con.close();
		return result;
	}
	
	public ArrayList<MyTechPojo> getMyTechDetails(String email) throws SQLException
	{
		System.out.println("i am hoooooooooooooooooooooooooo1111111111111");
		ArrayList<MyTechPojo> l1 = new ArrayList<MyTechPojo>();
		con =  GetConnection.getConnection();
		/*Statement stmt=con.createStatement();
		String query = "SELECT dateOfLacture,tital,discription,prasentator FROM TechDetail" ;
		ResultSet rst = stmt.executeQuery(query);*/
		
		
		PreparedStatement stmt = con.prepareStatement("SELECT * FROM MyTechDetail where email='"+email+"'");
		ResultSet rst= stmt.executeQuery();
		
		
		//System.out.println("i am hoooooooooooooooooooooooooo22222222222222222222");
		
		while(rst.next())
		{
			
			String dateOfLecture = rst.getDate("dateOfLacture")+"";
			String tital = rst.getString("tital");
			String discription = rst.getString("discription");
			String prentator = rst.getString("prasentator");
			//String interested = rst.getString("interested");
			System.out.println(dateOfLecture);
			l1.add(new MyTechPojo(dateOfLecture, tital, discription, prentator,email));
			
		}
		
		con.close();
		return l1;
		
	}
	
	
	
	
	
	
	
	public int updateinterest(TechPojo p_new) throws SQLException
	{
		String dateOfLecture_new = p_new.getDateOfLecture();
		String tital_new = p_new.getTital();
		String discription_new = p_new.getDiscription();
	
		String prentator_new = p_new.getPrentator();
		String interested = p_new.getInterested();
		
		
		con =  GetConnection.getConnection();
		Statement stmt=con.createStatement();
		
		String query = "update TechDetail set interested='"+interested+"' where "+ "dateOfLacture=TO_DATE ( '"+dateOfLecture_new+"','YYYY-MM-DD' ) AND tital='"+tital_new+"'AND discription='"+discription_new+"'AND prasentator='"+prentator_new+"'";
		
		System.out.println(query);
		int result = stmt.executeUpdate(query);
		con.commit();
		con.close();
		
		return result;
		
		
	}
	
	
	
	
	

}
