package pojo;

public class MyTechPojo extends TechPojo {
	
	String email;
	String dateOfLecture;
	String tital;
	String discription;
	String prentator;
	String interested;
	public MyTechPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public MyTechPojo(String dateOfLecture, String tital, String discription, String prentator, String interested,String email) {
		super(dateOfLecture, tital, discription, prentator, interested);
		this.email=email;
		// TODO Auto-generated constructor stub
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public MyTechPojo(String dateOfLecture, String tital, String discription, String prentator,String email) {
		super(dateOfLecture, tital, discription, prentator);
		this.email=email;
		// TODO Auto-generated constructor stub
	}
	

}
