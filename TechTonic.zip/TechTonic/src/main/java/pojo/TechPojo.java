package pojo;

public class TechPojo {
	
	String dateOfLecture;
	String tital;
	String discription;
	String prentator;
	String interested;
	public TechPojo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	public TechPojo(String dateOfLecture, String tital, String discription, String prentator, String interested) {
		super();
		this.dateOfLecture = dateOfLecture;
		this.tital = tital;
		this.discription = discription;
		this.prentator = prentator;
		this.interested = interested;
	}



	public String getInterested() {
		return interested;
	}



	public void setInterested(String interested) {
		this.interested = interested;
	}



	public TechPojo(String dateOfLecture, String tital, String discription, String prentator) {
		super();
		this.dateOfLecture = dateOfLecture;
		this.tital = tital;
		this.discription = discription;
		this.prentator = prentator;
	}
	public String getDateOfLecture() {
		return dateOfLecture;
	}
	public void setDateOfLecture(String dateOfLecture) {
		this.dateOfLecture = dateOfLecture;
	}
	public String getTital() {
		return tital;
	}
	public void setTital(String tital) {
		this.tital = tital;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public String getPrentator() {
		return prentator;
	}
	public void setPrentator(String prentator) {
		this.prentator = prentator;
	}
	@Override
	public String toString() {
		return "TechPojo [dateOfLecture=" + dateOfLecture + ", tital=" + tital + ", discription=" + discription
				+ ", prentator=" + prentator + "]";
	}
	
	

}
