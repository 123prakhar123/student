package pojo;

public class Login {
	
	String email;
	String password;
	public Login() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Login(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public String getEmail() {
		return email;
	}
	public String getPassword() {
		return password;
	}
	

}
