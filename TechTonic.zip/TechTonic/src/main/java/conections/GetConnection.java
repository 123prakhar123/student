package conections;

import java.sql.Connection;
import java.sql.DriverManager;

public class GetConnection {
	
	
	
	
	public static Connection getConnection()
	 {  
		 Connection con=null;
	try
	{  
	//step1 load the driver class  
	Class.forName("com.mysql.jdbc.Driver");  
	  
	//step2 create  the connection object  
	 con=DriverManager.getConnection(  
	"jdbc:mysql://localhost:3306/techdb", "root", "root");  
	  
	
	  
	}
	catch(Exception e)
	{ 
		System.out.println(e);
	}  
	  
	 
	 return con;
	} 
	 
}


