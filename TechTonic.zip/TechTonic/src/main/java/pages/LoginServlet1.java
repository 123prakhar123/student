package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.EmployeeDao;
import pojo.Employees_pojo;
import pojo.Login;

/**
 * Servlet implementation class LoginServlet1
 */
public class LoginServlet1 extends HttpServlet {
	
   

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		servrequest(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		servrequest(request, response);	
	}

	protected void servrequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		
		
		String email = request.getParameter("email");
		
		String password =  request.getParameter("password");
		
		
		Login l1 = new Login(email, password);
		
		EmployeeDao d1 = new EmployeeDao();
		boolean loginstatus=false;
		try {
			 loginstatus = d1.loginVarification(l1);
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		PrintWriter out = response.getWriter();
		if(loginstatus)
		{
			
			HttpSession session = request.getSession();
			session.setAttribute("email", email);
			session.setAttribute("password", password);
			
			if(email.equals("sanjay@atmecs.com"))
			{
				
				response.sendRedirect("AdminServletWellcome");
				
			}
			else
			{
				response.sendRedirect("EmployeeServletWellcome");
				
			}
			
		out.println("you are logedin");
		
		
		
		}
		else
			
			
			response.sendRedirect("Signup.jsp");
		
	}
	
}
