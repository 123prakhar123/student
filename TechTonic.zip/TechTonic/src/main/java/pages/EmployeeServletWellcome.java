package pages;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Dao.EmployeeDao;
import pojo.MyTechPojo;
import pojo.TechPojo;


@SuppressWarnings("serial")
public class EmployeeServletWellcome extends HttpServlet {
	
       
   

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		servrequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		servrequest(request,response);
	}
	
	protected void servrequest(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		HttpSession session = request.getSession();
		if(session.getAttribute("email")==null||session.getAttribute("password")==null)
				{
			
			response.sendRedirect("index.jsp");
			
			
				}
		
		else
		{
		EmployeeDao d1 = new EmployeeDao();
		try {
			ArrayList<TechPojo> l1 = d1.getTechDetails();
			System.out.println(session.getAttribute("email").toString()+"uuuuuuuuuuuuuuuuuu");
			System.out.println(l1+"uuuuuuuuuuuuuuuuuupppppppppppppppppppp");
			ArrayList<MyTechPojo>l2 = d1.getMyTechDetails(session.getAttribute("email").toString());
			request.setAttribute("listnew", l1);
			request.setAttribute("listmy", l2);
			System.out.println(l1+"llllllllllllllllllliiiiiiiiiiiiiiiisssssssssssssssstttttttttttttt");
			RequestDispatcher rd = request.getRequestDispatcher("tableOfTachTalk.jsp");
			//System.out.println("zzzzzzzzzzzzzzzzzzzzzzzzzzz");
			rd.forward(request, response);
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
	}
	}

}
